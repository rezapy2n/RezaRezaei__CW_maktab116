
class StringUtils:
    @staticmethod
    def reverse_string(s):
        return s[::-1]

    @staticmethod
    def capitalize_first_letter(s):
        return s.capitalize()

   
